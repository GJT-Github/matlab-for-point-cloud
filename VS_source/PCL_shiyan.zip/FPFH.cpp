
#define FPFH false                   //���ٵ���ֱ��ͼ��fpfh��
#define ICP true                     //ICP��׼

#if 0

#elif ICP
#include <pcl/registration/ia_ransac.h>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <pcl/features/normal_3d.h>
#include <pcl/features/fpfh.h>
#include <pcl/search/kdtree.h>
#include <pcl/io/pcd_io.h>
#include <pcl/io/ply_io.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/filter.h>
#include <pcl/registration/icp.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <time.h>



typedef pcl::PointXYZ PointT;
typedef pcl::PointCloud<PointT> PointCloud;

//���ƿ��ӻ�
void visualize_pcd(PointCloud::Ptr pcd_src,
    PointCloud::Ptr pcd_tgt,
    PointCloud::Ptr pcd_final)
{
    // Create a PCLVisualizer object
    pcl::visualization::PCLVisualizer viewer("registration Viewer");
    //viewer.createViewPort (0.0, 0, 0.5, 1.0, vp_1);
    // viewer.createViewPort (0.5, 0, 1.0, 1.0, vp_2);
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> src_h(pcd_src, 0, 255, 0);
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> tgt_h(pcd_tgt, 255, 0, 0);
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> final_h(pcd_final, 0, 0, 255);
    viewer.addPointCloud(pcd_src, src_h, "source cloud");
    viewer.addPointCloud(pcd_tgt, tgt_h, "tgt cloud");
    viewer.addPointCloud(pcd_final, final_h, "final cloud");
    //viewer.addCoordinateSystem(1.0);
    while (!viewer.wasStopped())
    {
        viewer.spinOnce(100);
        //boost::this_thread::sleep(boost::posix_time::microseconds(10000));   //��֧���ˣ���Ϊ��һ��
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }
}

//����תƽ�ƾ��������ת�Ƕ�
void Matrix2Angle(Eigen::Matrix4f& result_trans, Eigen::Vector3f& result_angle)
{
    double ax, ay, az;
    if (result_trans(2, 0) == 1 || result_trans(2, 0) == -1)
    {
        az = 0;
        double dlta;
        dlta = atan2(result_trans(0, 1), result_trans(0, 2));
        if (result_trans(2, 0) == -1)
        {
            ay = M_PI / 2;
            ax = az + dlta;
        }
        else
        {
            ay = -M_PI / 2;
            ax = -az + dlta;
        }
    }
    else
    {
        ay = -asin(result_trans(2, 0));
        ax = atan2(result_trans(2, 1) / cos(ay), result_trans(2, 2) / cos(ay));
        az = atan2(result_trans(1, 0) / cos(ay), result_trans(0, 0) / cos(ay));
    }
    result_angle << ax, ay, az;
}


void doRegistration(std::string src_cloud_path, std::string tgt_cloud_path, Eigen::Matrix4f& icp_trans)
{
    //���ص����ļ�
    PointCloud::Ptr cloud_src_origin(new PointCloud);//ԭ���ƣ�����׼
    pcl::io::loadPLYFile(src_cloud_path, *cloud_src_origin);
    PointCloud::Ptr cloud_tgt_origin(new PointCloud);//Ŀ�����
    pcl::io::loadPCDFile(tgt_cloud_path, *cloud_tgt_origin);

    clock_t start = clock();
    //ȥ��NAN��
    std::vector<int> indices_src; //����ȥ���ĵ������
    pcl::removeNaNFromPointCloud(*cloud_src_origin, *cloud_src_origin, indices_src);
    std::cout << "remove *cloud_src_origin nan" << endl;

    //�²����˲�
    pcl::VoxelGrid<pcl::PointXYZ> voxel_grid;
    voxel_grid.setLeafSize(0.014, 0.014, 0.014);
    voxel_grid.setInputCloud(cloud_src_origin);
    PointCloud::Ptr cloud_src(new PointCloud);
    voxel_grid.filter(*cloud_src);
    std::cout << "down size *cloud_src_origin from " << cloud_src_origin->size() << "to" << cloud_src->size() << endl;
    //pcl::io::savePCDFileASCII("monkey_src_down.pcd",*cloud_src);

    //������淨��
    pcl::NormalEstimation<pcl::PointXYZ, pcl::Normal> ne_src;
    ne_src.setInputCloud(cloud_src);
    pcl::search::KdTree< pcl::PointXYZ>::Ptr tree_src(new pcl::search::KdTree< pcl::PointXYZ>());
    ne_src.setSearchMethod(tree_src);
    pcl::PointCloud<pcl::Normal>::Ptr cloud_src_normals(new pcl::PointCloud< pcl::Normal>);
    ne_src.setRadiusSearch(0.02);
    ne_src.compute(*cloud_src_normals);

    std::vector<int> indices_tgt;
    pcl::removeNaNFromPointCloud(*cloud_tgt_origin, *cloud_tgt_origin, indices_tgt);
    std::cout << "remove *cloud_tgt_origin nan" << endl;

    pcl::VoxelGrid<pcl::PointXYZ> voxel_grid_2;
    voxel_grid_2.setLeafSize(0.01, 0.01, 0.01);
    voxel_grid_2.setInputCloud(cloud_tgt_origin);
    PointCloud::Ptr cloud_tgt(new PointCloud);
    voxel_grid_2.filter(*cloud_tgt);
    std::cout << "down size *cloud_tgt_origin.pcd from " << cloud_tgt_origin->size() << "to" << cloud_tgt->size() << endl;
    //pcl::io::savePCDFileASCII("monkey_tgt_down.pcd",*cloud_tgt);


    pcl::NormalEstimation<pcl::PointXYZ, pcl::Normal> ne_tgt;
    ne_tgt.setInputCloud(cloud_tgt);
    pcl::search::KdTree< pcl::PointXYZ>::Ptr tree_tgt(new pcl::search::KdTree< pcl::PointXYZ>());
    ne_tgt.setSearchMethod(tree_tgt);
    pcl::PointCloud<pcl::Normal>::Ptr cloud_tgt_normals(new pcl::PointCloud< pcl::Normal>);
    //ne_tgt.setKSearch(20);
    ne_tgt.setRadiusSearch(0.02);
    ne_tgt.compute(*cloud_tgt_normals);

    //����FPFH
    pcl::FPFHEstimation<pcl::PointXYZ, pcl::Normal, pcl::FPFHSignature33> fpfh_src;
    fpfh_src.setInputCloud(cloud_src);
    fpfh_src.setInputNormals(cloud_src_normals);
    pcl::search::KdTree<PointT>::Ptr tree_src_fpfh(new pcl::search::KdTree<PointT>);
    fpfh_src.setSearchMethod(tree_src_fpfh);
    pcl::PointCloud<pcl::FPFHSignature33>::Ptr fpfhs_src(new pcl::PointCloud<pcl::FPFHSignature33>());
    fpfh_src.setRadiusSearch(0.05);
    fpfh_src.compute(*fpfhs_src);
    std::cout << "compute *cloud_src fpfh" << endl;

    pcl::FPFHEstimation<pcl::PointXYZ, pcl::Normal, pcl::FPFHSignature33> fpfh_tgt;
    fpfh_tgt.setInputCloud(cloud_tgt);
    fpfh_tgt.setInputNormals(cloud_tgt_normals);
    pcl::search::KdTree<PointT>::Ptr tree_tgt_fpfh(new pcl::search::KdTree<PointT>);
    fpfh_tgt.setSearchMethod(tree_tgt_fpfh);
    pcl::PointCloud<pcl::FPFHSignature33>::Ptr fpfhs_tgt(new pcl::PointCloud<pcl::FPFHSignature33>());
    fpfh_tgt.setRadiusSearch(0.05);
    fpfh_tgt.compute(*fpfhs_tgt);
    std::cout << "compute *cloud_tgt fpfh" << endl;


    //SAC��׼
    pcl::SampleConsensusInitialAlignment<pcl::PointXYZ, pcl::PointXYZ, pcl::FPFHSignature33> scia;
    scia.setInputSource(cloud_src);
    scia.setInputTarget(cloud_tgt);
    scia.setSourceFeatures(fpfhs_src);
    scia.setTargetFeatures(fpfhs_tgt);
    //scia.setMinSampleDistance(1);
    //scia.setNumberOfSamples(2);
    //scia.setCorrespondenceRandomness(20);
    PointCloud::Ptr sac_result(new PointCloud);
    scia.align(*sac_result);
    std::cout << "sac has converged:" << scia.hasConverged() << "  score: " << scia.getFitnessScore() << endl;
    Eigen::Matrix4f sac_trans;
    sac_trans = scia.getFinalTransformation();
    std::cout << sac_trans << endl;
    //pcl::io::savePCDFileASCII("monkey_transformed_sac.pcd",*sac_result);
    clock_t sac_time = clock();



    //���ӻ�
    visualize_pcd(cloud_src, cloud_tgt, cloud_tgt);








    //icp��׼
    PointCloud::Ptr icp_result(new PointCloud);
    pcl::IterativeClosestPoint<pcl::PointXYZ, pcl::PointXYZ> icp;
    icp.setInputSource(cloud_src);
    icp.setInputTarget(cloud_tgt_origin);
    icp.setMaxCorrespondenceDistance(0.04);
    // ����������
    icp.setMaximumIterations(2);
    // ���α仯����֮��Ĳ�ֵ
    icp.setTransformationEpsilon(1e-10);
    // �������
    icp.setEuclideanFitnessEpsilon(0.2);
    icp.align(*icp_result, sac_trans);

    clock_t end = clock();
    cout << "total time: " << (double)(end - start) / (double)CLOCKS_PER_SEC << " s" << endl;

    cout << "sac time: " << (double)(sac_time - start) / (double)CLOCKS_PER_SEC << " s" << endl;
    cout << "icp time: " << (double)(end - sac_time) / (double)CLOCKS_PER_SEC << " s" << endl;

    std::cout << "ICP has converged:" << icp.hasConverged()
        << " score: " << icp.getFitnessScore() << std::endl;

    icp_trans = icp.getFinalTransformation();
    //cout<<"ransformationProbability"<<icp.getTransformationProbability()<<endl;
    std::cout << icp_trans << endl;
    //ʹ�ô����ı任��δ���˵�������ƽ��б任
    pcl::transformPointCloud(*cloud_src_origin, *icp_result, icp_trans);
    //����ת�����������
    //pcl::io::savePCDFileASCII("monkey_transformed_sac_ndt.pcd", *icp_result);

    //�������
    Eigen::Vector3f ANGLE_origin;
    ANGLE_origin << 0, 0, M_PI / 5;
    double error_x, error_y, error_z;
    Eigen::Vector3f ANGLE_result;
    Matrix2Angle(icp_trans, ANGLE_result);
    error_x = fabs(ANGLE_result(0)) - fabs(ANGLE_origin(0));
    error_y = fabs(ANGLE_result(1)) - fabs(ANGLE_origin(1));
    error_z = fabs(ANGLE_result(2)) - fabs(ANGLE_origin(2));
    cout << "original angle in x y z:\n" << ANGLE_origin << endl;
    cout << "error in aixs_x: " << error_x << "  error in aixs_y: " << error_y << "  error in aixs_z: " << error_z << endl;
    //���ӻ�
    visualize_pcd(cloud_src_origin, cloud_tgt_origin, icp_result);
}

int
main(int argc, char** argv)
{
    std::string src_cloud_path = "./monkey.ply";
    std::string tgt_cloud_path = "./monkey_downsampled.pcd";
    Eigen::Matrix4f icp_trans;
    doRegistration(src_cloud_path, tgt_cloud_path, icp_trans);
    return (0);
}



#elif FPFH


#include <pcl/io/pcd_io.h>
#include <pcl/io/ply_io.h>
#include <ctime>
#include <Eigen/Core>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <pcl/features/fpfh.h>
#include <pcl/registration/ia_ransac.h>
#include <pcl/features/normal_3d.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <boost/thread/thread.hpp>
#include <pcl/features/fpfh_omp.h> //����fpfh���ټ����omp(��˲��м���)
#include <pcl/registration/correspondence_estimation.h>
#include <pcl/registration/correspondence_rejection_features.h> //�����Ĵ����Ӧ��ϵȥ��
#include <pcl/registration/correspondence_rejection_sample_consensus.h> //�������һ����ȥ��
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/approximate_voxel_grid.h>

using namespace std;
typedef pcl::PointCloud<pcl::PointXYZ> pointcloud;
typedef pcl::PointCloud<pcl::Normal> pointnormal;
typedef pcl::PointCloud<pcl::FPFHSignature33> fpfhFeature;

fpfhFeature::Ptr compute_fpfh_feature(pointcloud::Ptr input_cloud, pcl::search::KdTree<pcl::PointXYZ>::Ptr tree)
{
    //������
    pointnormal::Ptr point_normal(new pointnormal);
    pcl::NormalEstimation<pcl::PointXYZ, pcl::Normal> est_normal;
    est_normal.setInputCloud(input_cloud);
    est_normal.setSearchMethod(tree);
    est_normal.setKSearch(10);
    est_normal.compute(*point_normal);
    //fpfh ����
    fpfhFeature::Ptr fpfh(new fpfhFeature);
    //pcl::FPFHEstimation<pcl::PointXYZ,pcl::Normal,pcl::FPFHSignature33> est_target_fpfh;
    pcl::FPFHEstimationOMP<pcl::PointXYZ, pcl::Normal, pcl::FPFHSignature33> est_fpfh;
    est_fpfh.setNumberOfThreads(4); //ָ��4�˼���
    // pcl::search::KdTree<pcl::PointXYZ>::Ptr tree4 (new pcl::search::KdTree<pcl::PointXYZ> ());
    est_fpfh.setInputCloud(input_cloud);
    est_fpfh.setInputNormals(point_normal);
    est_fpfh.setSearchMethod(tree);
    est_fpfh.setKSearch(10);
    est_fpfh.compute(*fpfh);

    return fpfh;

}


#define load_point(format,input,point)  if (format == ".ply")       \
                             pcl::io::loadPLYFile(input, *point);   \
                            else if (format == ".pcd")pcl::io::loadPCDFile(input, *point);



int main(int argc, char** argv)
{


   
    if (argc < 3)
    {
        cout << "please input two pointcloud" << endl;
        return -1;
    }
    clock_t start, end, time;
    start = clock();
    pointcloud::Ptr source(new pointcloud);
    pointcloud::Ptr target(new pointcloud);
    pcl::search::KdTree<pcl::PointXYZ>::Ptr tree(new pcl::search::KdTree<pcl::PointXYZ>());


    string input_filename = argv[1];
    string output_filename = argv[2];


    std::string format = input_filename.substr(input_filename.length() - 4, 4);
    //std::cout<<"pointcloud format:"<<format<<std::endl;
    ///*if (format == ".ply")
    //{
    //    pcl::io::loadPLYFile(input_filename, *source);
    //    pcl::io::loadPLYFile(output_filename, *target);
    //}
    //else if (format == ".pcd")
    //{
    //    pcl::io::loadPCDFile(input_filename, *source);
    //    pcl::io::loadPCDFile(output_filename, *target);
    //}*/
    load_point(format, input_filename, source)
    format = output_filename.substr(output_filename.length() - 4, 4);
    load_point(format, output_filename, target)


    fpfhFeature::Ptr source_fpfh = compute_fpfh_feature(source, tree);
    fpfhFeature::Ptr target_fpfh = compute_fpfh_feature(target, tree);

    //����(ռ���˴󲿷�����ʱ��)
    pcl::SampleConsensusInitialAlignment<pcl::PointXYZ, pcl::PointXYZ, pcl::FPFHSignature33> sac_ia;
    sac_ia.setInputSource(source);
    sac_ia.setSourceFeatures(source_fpfh);
    sac_ia.setInputTarget(target);
    sac_ia.setTargetFeatures(target_fpfh);
    pointcloud::Ptr align(new pointcloud);
    //  sac_ia.setNumberOfSamples(20);  //����ÿ�ε���������ʹ�õ�������������ʡ��,�ɽ�ʡʱ��
    //sac_ia.setCorrespondenceRandomness(6); //���ü���Э����ʱѡ����ٽ��ڵ㣬��ֵԽ��Э����Խ��ȷ�����Ǽ���Ч��Խ��.(��ʡ)
    sac_ia.align(*align);
    end = clock();
    cout << "calculate time is: " << float(end - start) / CLOCKS_PER_SEC << endl;

    //���ӻ�
    boost::shared_ptr<pcl::visualization::PCLVisualizer> view(new pcl::visualization::PCLVisualizer("fpfh test"));
    int v1;
    int v2;

    view->createViewPort(0, 0.0, 0.5, 1.0, v1);
    view->createViewPort(0.5, 0.0, 1.0, 1.0, v2);
    view->setBackgroundColor(0, 0, 0, v1);
    view->setBackgroundColor(0.05, 0, 0, v2);
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> sources_cloud_color(source, 250, 0, 0);
    view->addPointCloud(source, sources_cloud_color, "sources_cloud_v1", v1);
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> target_cloud_color(target, 0, 250, 0);
    view->addPointCloud(target, target_cloud_color, "target_cloud_v1", v1);
    view->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 2, "sources_cloud_v1");

    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ>aligend_cloud_color(align, 255, 0, 0);
    view->addPointCloud(align, aligend_cloud_color, "aligend_cloud_v2", v2);
    view->addPointCloud(target, target_cloud_color, "target_cloud_v2", v2);
    view->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 4, "aligend_cloud_v2");
    view->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 2, "target_cloud_v2");

    //   view->addCorrespondences<pcl::PointXYZ>(source,target,*cru_correspondences,"correspondence",v1);//������ʾ��Ӧ���
    while (!view->wasStopped())
    {
        // view->spin();
        view->spinOnce(100);
        boost::this_thread::sleep(boost::posix_time::microseconds(100000));


    }
    pcl::io::savePCDFile("crou_output.pcd", *align);
    //  pcl::io::savePCDFile ("final_align.pcd", *final);

    return 0;
}

#if 0
//pcl::ApproximateVoxelGrid<pcl::PointXYZ> approximate_voxel_grid;
pcl::VoxelGrid<pcl::PointXYZ> approximate_voxel_grid;
approximate_voxel_grid.setLeafSize(0.5, 0.5, 0.5); //����߳�.�������ֵԽ���򾫼��Խ������ʣ�µ������٣�
pointcloud::Ptr source(new pointcloud);
pointcloud::Ptr sample_sources(new pointcloud);
approximate_voxel_grid.setInputCloud(source);
approximate_voxel_grid.filter(*sample_source);
cout << "source voxel grid  Filte cloud size is " << sample_source->size() << endl;
// pcl::io::savePCDFile("voxelgrid.pcd",*out);


pcl::registration::CorrespondenceEstimation<pcl::FPFHSignature33, pcl::FPFHSignature33> crude_cor_est;

boost::shared_ptr<pcl::Correspondences> cru_correspondences(new pcl::Correspondences);
crude_cor_est.setInputSource(source_fpfh);
crude_cor_est.setInputTarget(target_fpfh);
//  crude_cor_est.determineCorrespondences(cru_correspondences);
crude_cor_est.determineReciprocalCorrespondences(*cru_correspondences);
cout << "crude size is:" << cru_correspondences->size() << endl;

#endif


#endif // 0

